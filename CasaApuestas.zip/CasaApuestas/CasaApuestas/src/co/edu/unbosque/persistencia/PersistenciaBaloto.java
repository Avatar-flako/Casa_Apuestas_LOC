package co.edu.unbosque.persistencia;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import co.edu.unbosque.model.Baloto;
/**
 * @author oscar,claudia,luis,jorge
 *  Clase PersistenciaBaloto
 *  Procesa el archivo del baloto y enlista la informacion
 */
public class PersistenciaBaloto {
/**
 * se instancian los objetos o variables que se van a utilizar en la clase
 */
	private InputStream entrada;
	private ObjectInputStream entradaBinario;
	private ObjectOutputStream salidaBinario;
	private File archivo = new File("data/apuestas-baloto.dat");

	public PersistenciaBaloto() {
		cargarArchivoBinario();
	}
    /**
	 * valida la existencia del archivo
	 */
	private void cargarArchivoBinario() {
		if (archivo.exists()) {
		} else {
			try {
				archivo.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
/**
 * metodo que guarda en el archivo
 * @param lista parametro en la cual se guardan los valores en la lista
 * @return true or falsa diciendo si se guard� o no 
 */
	public boolean guardarEnArchivo(List<Baloto> lista) {
		try {
			salidaBinario = new ObjectOutputStream(new FileOutputStream(archivo));
			salidaBinario.writeObject(lista);
			salidaBinario.close();
			return true;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
/**
 * metodo que lee el archivo en la lista 
 * @return lee la lista completamente
 */
	public List<Baloto> leerArchivo() {
		List<Baloto> lista = new ArrayList<Baloto>();
		if (archivo.length() != 0) {
			try {
				entradaBinario = new ObjectInputStream(new FileInputStream(archivo));
				lista = (List<Baloto>) entradaBinario.readObject();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
		return lista;
	}
/**
 * nos trae el archivo para poder leerlo
 * @return retorna entrada
 */
	public InputStream getEntrada() {
		return entrada;
	}
/**
 * actualiza para poder leer el archivo
 * @param entrada setEntrada
 */
	public void setEntrada(InputStream entrada) {
		this.entrada = entrada;
	}
/**
 * nos trae el archivo binario para la lectura 
 * @return retorna entradaBinario
 */
	public ObjectInputStream getEntradaBinario() {
		return entradaBinario;
	}
/**
 * nos permite actualizar el archivo binario
 * @param entradaBinario setEntradaBinario
 */ 
	public void setEntradaBinario(ObjectInputStream entradaBinario) {
		this.entradaBinario = entradaBinario;
	}
/**
 * nos permite traer el archivo para finalizar
 * @return retorna salidaBinario
 */
	public ObjectOutputStream getSalidaBinario() {
		return salidaBinario;
	}
/**
 * nos permite cerrar el archivo despues de actualizarlo
 * @param salidaBinario setSalidaBinario
 */
	public void setSalidaBinario(ObjectOutputStream salidaBinario) {
		this.salidaBinario = salidaBinario;
	}
/**
 * get que nos trae el archivo
 * @return retorna archivo
 */
	public File getArchivo() {
		return archivo;
	}
/**
 * set que nos actualiza el archivo
 * @param archivo setArchivo
 */
	public void setArchivo(File archivo) {
		this.archivo = archivo;
	}

}