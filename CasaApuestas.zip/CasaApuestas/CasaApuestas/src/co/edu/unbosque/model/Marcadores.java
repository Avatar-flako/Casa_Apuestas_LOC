package co.edu.unbosque.model;
/**
 * Clase Marcadores
 *
 */
public class Marcadores extends Apuesta {
	/**
     * Se crea una constante local de la clase 
     */
	public static final String LOCAL = "local";
	/**
     * Se crea una constante visitante de la clase 
     */
	public static final String VISITANTE = "visitante";
	/**
     * Se crea una constante empate de la clase 
     */
	public static final String EMPATE = "empate";
	

	/**
	 * partido1
	 */
	private String partido1;
	/**
	 * partido2
	 */
	private String partido2;
	/**
	 * partido3
	 */
	private String partido3;
	/**
	 * partido4
	 */
	private String partido4;
	/**
	 * partido5
	 */
	private String partido5;
	/**
	 * partido6
	 */
	private String partido6;
	/**
	 * partido7
	 */
	private String partido7;
	/**
	 * partido8
	 */
	private String partido8;
	/**
	 * partido9
	 */
	private String partido9;
	/**
	 * partido10
	 */
	private String partido10;
	/**
	 * partido11
	 */
	private String partido11;
	/**
	 * partido12
	 */
	private String partido12;
	/**
	 * partido13
	 */
	private String partido13;
	/**
	 * partido14
	 */
	private String partido14;

	public Marcadores() {
		super();
	}
	
	/**
	 * Constructor con 14 parametros
	 * 
	 * @param partido1 String partido1
	 * @param partido2 String partido2
	 * @param partido3 String partido3
	 * @param partido4 String partido4
	 * @param partido5 String partido5
	 * @param partido6 String partido6
	 * @param partido7 String partido7
	 * @param partido8 String partido8
	 * @param partido9 String partido9
	 * @param partido10 String partido10
	 * @param partido11 String partido11
	 * @param partido12 String partido12
	 * @param partido13 String partido13
	 * @param partido14 String partido14
	 */
	public Marcadores(String partido1, String partido2, String partido3, String partido4, String partido5,
			String partido6, String partido7, String partido8, String partido9, String partido10, String partido11,
			String partido12, String partido13, String partido14) {
		super();
		this.partido1 = partido1;
		this.partido2 = partido2;
		this.partido3 = partido3;
		this.partido4 = partido4;
		this.partido5 = partido5;
		this.partido6 = partido6;
		this.partido7 = partido7;
		this.partido8 = partido8;
		this.partido9 = partido9;
		this.partido10 = partido10;
		this.partido11 = partido11;
		this.partido12 = partido12;
		this.partido13 = partido13;
		this.partido14 = partido14;
	}

	/**
     * Metodo que regresa el partido1
     * @return Regresa el partido1
     */
	public String getPartido1() {
		return partido1;
	}
	 /**
     * Metodo que le asigna el partido1
     * @param partido1 setPartido1
     */
	public void setPartido1(String partido1) {
		this.partido1 = partido1;
	}
	/**
     * Metodo que regresa el partido2
     * @return Regresa el partido2
     */
	public String getPartido2() {
		return partido2;
	}
	/**
     * Metodo que le asigna el partido2
     * @param partido2 setPartido2
     */
	public void setPartido2(String partido2) {
		this.partido2 = partido2;
	}
	/**
     * Metodo que regresa el partido3
     * @return Regresa el partido3
     */
	public String getPartido3() {
		return partido3;
	}
	/**
     * Metodo que le asigna el partido3
     * @param partido3 setPartido3
     */
	public void setPartido3(String partido3) {
		this.partido3 = partido3;
	}
	/**
     * Metodo que regresa el partido4
     * @return Regresa el partido4
     */
	public String getPartido4() {
		return partido4;
	}
	/**
     * Metodo que le asigna el partido4
     * @param partido4 setPartido4
     */
	public void setPartido4(String partido4) {
		this.partido4 = partido4;
	}
	/**
     * Metodo que regresa el partido5
     * @return Regresa el partido5
     */
	public String getPartido5() {
		return partido5;
	}
	/**
     * Metodo que le asigna el partido5
     * @param partido5 setPartido5
     */
	public void setPartido5(String partido5) {
		this.partido5 = partido5;
	}
	/**
     * Metodo que regresa el partido6
     * @return Regresa el partido6
     */
	public String getPartido6() {
		return partido6;
	}
	/**
     * Metodo que le asigna el partido6
     * @param partido6 setPartido6
     */
	public void setPartido6(String partido6) {
		this.partido6 = partido6;
	}
	/**
     * Metodo que regresa el partido7
     * @return Regresa el partido7
     */
	public String getPartido7() {
		return partido7;
	}
	/**
     * Metodo que le asigna el partido7
     * @param partido7 setPartido7
     */
	public void setPartido7(String partido7) {
		this.partido7 = partido7;
	}
	/**
     * Metodo que regresa el partido8
     * @return Regresa el partido8
     */
	public String getPartido8() {
		return partido8;
	}
	/**
     * Metodo que le asigna el partido8
     * @param partido8 setPartido8
     */
	public void setPartido8(String partido8) {
		this.partido8 = partido8;
	}
	/**
     * Metodo que regresa el partido9
     * @return Regresa el partido9
     */
	public String getPartido9() {
		return partido9;
	}
	/**
     * Metodo que le asigna el partido8
     * @param partido9 setPartido9
     */
	public void setPartido9(String partido9) {
		this.partido9 = partido9;
	}
	/**
     * Metodo que regresa el partido10
     * @return Regresa el partido10
     */
	public String getPartido10() {
		return partido10;
	}
	/**
     * Metodo que le asigna el partido10
     * @param partido10 setPartido10
     */
	public void setPartido10(String partido10) {
		this.partido10 = partido10;
	}
	/**
     * Metodo que regresa el partido11
     * @return Regresa el partido11
     */
	public String getPartido11() {
		return partido11;
	}
	/**
     * Metodo que le asigna el partido11
     * @param partido11 setPartido11
     */
	public void setPartido11(String partido11) {
		this.partido11 = partido11;
	}
	/**
     * Metodo que regresa el partido12
     * @return Regresa el partido12
     */
	public String getPartido12() {
		return partido12;
	}
	/**
     * Metodo que le asigna el partido12
     * @param partido12 setPartido12
     */
	public void setPartido12(String partido12) {
		this.partido12 = partido12;
	}
	/**
     * Metodo que regresa el partido13
     * @return Regresa el partido13
     */
	public String getPartido13() {
		return partido13;
	}
	/**
     * Metodo que le asigna el partido13
     * @param partido13 setPartido13
     */
	public void setPartido13(String partido13) {
		this.partido13 = partido13;
	}
	/**
     * Metodo que regresa el partido14
     * @return Regresa el partido14
     */
	public String getPartido14() {
		return partido14;
	}
	/**
     * Metodo que le asigna el partido14
     * @param partido14 setPartido14
     */
	public void setPartido14(String partido14) {
		this.partido14 = partido14;
	}

}
