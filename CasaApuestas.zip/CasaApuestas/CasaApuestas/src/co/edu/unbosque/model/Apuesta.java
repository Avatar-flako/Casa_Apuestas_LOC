package co.edu.unbosque.model;

import java.io.Serializable;
import java.util.Date;
/**
 * Clase Apuesta
 *
 */
public class Apuesta implements Serializable {
	/**
	 * sede de la apuesta
	 */
	private String sede;
	/**
	 * cedula del apostador
	 */
	private Long cedula;
	/**
	 * fecha de la apuesta
	 */
	private Date fecha;
	/**
	 * valor de la apuesta
	 */
	private Long valor;

	public Apuesta() {
	}
	/**
     * Metodo que regresa la sede de la apuesta
     * @return Regresa el nombre
     */
	public String getSede() {
		return sede;
	}
	/**
     * Metodo que le asigna la sede  de la apuesta
     * @param sede set sede
     */
	public void setSede(String sede) {
		this.sede = sede;
	}
	/**
     * Metodo que regresa la cedula del apostador
     * @return Regresa la cedula
     */
	public Long getCedula() {
		return cedula;
	}
	/**
     * Metodo que le asigna la cedula a una apuesta
     * @param cedula set cedula
     */
	public void setCedula(Long cedula) {
		this.cedula = cedula;
	}
	/**
     * Metodo que regresa la fecha de la apuesta
     * @return Regresa la fecha
     */
	public Date getFecha() {
		return fecha;
	}
	/**
     * Metodo que le asigna la fecha  de la apuesta
     * @param fecha set fecha
     */
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	/**
     * Metodo que regresa el valor de la apuesta
     * @return Regresa el valor
     */
	public Long getValor() {
		return valor;
	}
	/**
     * Metodo que le asigna el valor de la apuesta
     * @param valor set valor
     */
	public void setValor(Long valor) {
		this.valor = valor;
	}

}
