package co.edu.unbosque.model;
/**
 * Clase Super Astro
 * 
 */
public class SuperAstro extends Apuesta {

	/**
     * Se crea una constante acuario  de la clase 
     */
	public static final String ACUARIO = "acuario";
	/**
     * Se crea una constante picis  de la clase 
     */
	public static final String PISCIS = "piscis";
	/**
     * Se crea una constante aries  de la clase 
     */
	public static final String ARIES = "aries";
	/**
     * Se crea una constante tauro de la clase 
     */
	public static final String TAURO = "tauro";
	/**
     * Se crea una constante geminis  de la clase 
     */
	public static final String GEMINIS = "geminis";
	/**
     * Se crea una constante cancer  de la clase 
     */
	public static final String CANCER = "cancer";
	/**
     * Se crea una constante leo  de la clase 
     */
	public static final String LEO = "leo";
	/**
     * Se crea una constante virgo  de la clase 
     */
	public static final String VIRGO = "virgo";
	/**
     * Se crea una constante libra  de la clase 
     */
	public static final String LIBRA = "libra";
	/**
     * Se crea una constante escorpio  de la clase 
     */
	public static final String ESCORPIO = "escorpio";
	/**
     * Se crea una constante sagitario  de la clase 
     */
	public static final String SAGITARIO = "sagitario";
	/**
     * Se crea una constante capricornio  de la clase 
     */
	public static final String CAPRICORNIO = "capricornio";
	
	/**
	 * Numero del SuperAstro
	 */
	private int numero;
	/**
	 * Signo del SuperAstro
	 */
	private String signo;
	
	public SuperAstro() {
		super();
	}
	/**
     * Metodo que regresa el Numero del SuperAstro
     * @return Regresa el Numero del SuperAstro
     */
	public int getNumero() {
		return numero;
	}
	 
	/**
	 * Metodo que le asigna Numero del SuperAstro
	 * @param numero setNumero
	 */
	public void setNumero(int numero) {
		this.numero = numero;
	}
	/**
     * Metodo que regresa el signo del SuperAstro
     * @return Regresa el signo del SuperAstro
     */
	public String getSigno() {
		return signo;
	}
	 
	/**
	 * Metodo que le asigna el signo del SuperAstro
	 * @param signo setSigno
	 */
	public void setSigno(String signo) {
		this.signo = signo;
	}
	
	

}
