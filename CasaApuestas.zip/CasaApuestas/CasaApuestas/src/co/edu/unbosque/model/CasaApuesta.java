package co.edu.unbosque.model;

import java.io.Serializable;
/**
 * Clase CasaApuesta
 *
 */
public class CasaApuesta implements Serializable{
	/**
	 * nombreCasaApuesta
	 */
	private String nombreCasaApuesta;
	/**
	 * numeroSede
	 */
	private int numeroSede;
	/**
	 * presupuestoPremiacion
	 */
	private double presupuestoPremiacion;
	
	public CasaApuesta() {
	}
	
	
	/**
     * Metodo que regresa el nombre casa Apuesta
     * @return Regresa el NombreCasaApuesta
     */
	public String getNombreCasaApuesta() {
		return nombreCasaApuesta;
	}
	 /**
     * Metodo que le asigna nombre casa Apuesta
     * @param nombreCasaApuesta setNombreCasaApuesta
     */

	public void setNombreCasaApuesta(String nombreCasaApuesta) {
		this.nombreCasaApuesta = nombreCasaApuesta;
	}
	/**
     * Metodo que regresa el numero de sede
     * @return Regresa el numero de sede 
     */
	public int getNumeroSede() {
		return numeroSede;
	}
	 /**
     * Metodo que le asigna numero de sede
     * @param numeroSede setNumeroSede
     */
	public void setNumeroSede(int numeroSede) {
		this.numeroSede = numeroSede;
	}
	/**
     * Metodo que regresa el presupuesto de la premiacion
     * @return Regresa el presupuesto de la premiacion
     */
	public double getPresupuestoPremiacion() {
		return presupuestoPremiacion;
	}
	/**
     * Metodo que le asigna presupuesto de la premiacion
     * @param presupuestoPremiacion setPresupuestoPremiacion
     */
	
	public void setPresupuestoPremiacion(double presupuestoPremiacion) {
		this.presupuestoPremiacion = presupuestoPremiacion;
	}

}
