package co.edu.unbosque.model;

import java.io.Serializable;

/**
 * Clase Apostador
 * 
 */
public class Apostador implements Serializable {

	/**
	 * Nombre del apostador
	 */
	private String nombre;
	/**
	 * Cedula del apostador
	 */
	private long cedula;
	/**
	 * Sede del apostador
	 */
	private String sede;
	/**
	 * Direcci�n del apostador
	 */
	private String direccion;
	/**
	 * Celular del apostador
	 */
	private long celular;

	public Apostador() {

	}

	/**
	 * Constructor con 5 parametros
	 * 
	 * @param nombre    nombre del apostador
	 * @param cedula    cedula del apostador
	 * @param sede      sede del apostador
	 * @param direccion direccion del apostador
	 * @param celular   celular del apostador
	 */

	public Apostador(String nombre, long cedula, String sede, String direccion, long celular) {
		super();
		this.nombre = nombre;
		this.cedula = cedula;
		this.sede = sede;
		this.direccion = direccion;
		this.celular = celular;
	}
	/**
     * Metodo que regresa el nombre del apostador
     * @return Regresa el nombre
     */
	public String getNombre() {
		return nombre;
	}
	 /**
     * Metodo que le asigna nombre a un apostador
	 * @param nombre set nombre
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
     * Metodo que regresa la cedula del apostador
     * @return Regresa la cedula
     */
	public long getCedula() {
		return cedula;
	}
	/**
     * Metodo que le asigna la cedula a un apostador
     * @param cedula set cedula
     */
	public void setCedula(long cedula) {
		this.cedula = cedula;
	}
	/**
     * Metodo que regresa la sede del apostador
     * @return Regresa la sede
     */
	public String getSede() {
		return sede;
	}
	/**
     * Metodo que le asigna la sede a un apostador
     * @param sede set sede
     */
	public void setSede(String sede) {
		this.sede = sede;
	}
	/**
     * Metodo que regresa la direccion del apostador
     * @return Regresa la direccion
     */
	public String getDireccion() {
		return direccion;
	}
	/**
     * Metodo que le asigna la direccion a un apostador
     * @param direccion set direccion
     */
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	/**
     * Metodo que regresa el celular del apostador
     * @return Regresa el celular direccion
     */
	public long getCelular() {
		return celular;
	}
	/**
     * Metodo que le asigna el celular a un apostador
     * @param celular set celular
     */
	public void setCelular(long celular) {
		this.celular = celular;
	}

}
