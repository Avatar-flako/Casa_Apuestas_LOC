package co.edu.unbosque.model;
/**
 * Clase Baloto
 *
 */
public class Baloto extends Apuesta {
	/**
	 * numero  del baloto
	 */
	private Long numero;
	/**
     * Metodo que regresa el numero del baloto
     * @return Regresa el numero
     */
	public Long getNumero() {
		return numero;
	}
	 /**
     * Metodo que le asigna el numero al baloto
     * @param numero set numero
     */
	public void setNumero(Long numero) {
		this.numero = numero;
	}

	
}
