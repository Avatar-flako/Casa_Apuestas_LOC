package co.edu.unbosque.model;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;
/**
 * Clase PremioSuperAstroModel
 * 
 */
public class PremioSuperAstroModel implements Serializable {
	/**
	 * Fecha del marcador
	 */
	private Date fecha;
	/**
	 * numero del SuperAstro
	 */
	private Long numero;
	/**
	 * Lista de ganadores
	 */
	private List<String> listaGanadores;
	
	public PremioSuperAstroModel() {
	}
	/**
     * Metodo que regresa la fecha del Super Astro
     * @return Regresa la fecha del Super Astro
     */
	public Date getFecha() {
		return fecha;
	}
	
	/**
	 * Metodo que le asigna la fecha del Super Astro
	 * @param fecha setFecha
	 */
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	/**
     * Metodo que regresa el numero del Super Astro
     * @return Regresa el numero del Super Astro
     */
	public Long getNumero() {
		return numero;
	}
	
	/**
	 * Metodo que le asigna el numero del Super Astro
	 * @param numero setNumero
	 */
	public void setNumero(Long numero) {
		this.numero = numero;
	}
	/**
     * Metodo que regresa la lista de ganadores
     * @return Regresa la lista de ganadores
     */
	public List<String> getListaGanadores() {
		return listaGanadores;
	}
	
	/**
	 * Metodo que le asigna el numero del Super Astro
	 * @param listaGanadores setListaGanadores
	 */
	public void setListaGanadores(List<String> listaGanadores) {
		this.listaGanadores = listaGanadores;
	}

	
}
