package co.edu.unbosque.model;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;
/**
 * Clase Premio Marcador Model
 * 
 */
public class PremioMarcadorModel implements Serializable {

	/**
	 * Fecha del marcador
	 */
	private Date fecha;
	/**
	 * partido1
	 */
	private String partido1;
	/**
	 * partido2
	 */
	private String partido2;
	/**
	 * partido3
	 */
	private String partido3;
	/**
	 * partido4
	 */
	private String partido4;
	/**
	 * partido5
	 */
	private String partido5;
	/**
	 * partido6
	 */
	private String partido6;
	/**
	 * partido7
	 */
	private String partido7;
	/**
	 * partido8
	 */
	private String partido8;
	/**
	 * partido9
	 */
	private String partido9;
	/**
	 * partido10
	 */
	private String partido10;
	/**
	 * partido11
	 */
	private String partido11;
	/**
	 * partido12
	 */
	private String partido12;
	/**
	 * partido13
	 */
	private String partido13;
	/**
	 * partido14
	 */
	private String partido14;
	/**
	 * Lista de Ganadores
	 */
	private List<String> listaGanadores;
	
	
	public PremioMarcadorModel() {
	}

	/**
     * Metodo que regresa la fecha del marcador
     * @return Regresa la fecha del marcador
     */

	public Date getFecha() {
		return fecha;
	}
	/**
     * Metodo que le asigna la fecha del marcador
     * @param fecha setFecha
     */
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	/**
     * Metodo que regresa el partido1 del marcador
     * @return Regresa la partido1 del marcador
     */
	public String getPartido1() {
		return partido1;
	}
	/**
     * Metodo que le asigna el partido1 del marcador
     * @param partido1 setPartido1
     */
	public void setPartido1(String partido1) {
		this.partido1 = partido1;
	}
	/**
     * Metodo que regresa el partido2 del marcador
     * @return Regresa la partido2 del marcador
     */
	public String getPartido2() {
		return partido2;
	}
	/**
     * Metodo que le asigna el partido2 del marcador
     * @param partido2 setPartido2
     */
	public void setPartido2(String partido2) {
		this.partido2 = partido2;
	}
	/**
     * Metodo que regresa el partido3 del marcador
     * @return Regresa la partido3 del marcador
     */
	public String getPartido3() {
		return partido3;
	}
	/**
     * Metodo que le asigna el partido3 del marcador
     * @param partido3 setPartido3
     */
	public void setPartido3(String partido3) {
		this.partido3 = partido3;
	}
	/**
     * Metodo que regresa el partido4 del marcador
     * @return Regresa la partido4 del marcador
     */
	public String getPartido4() {
		return partido4;
	}
	
	/**
	 * Metodo que le asigna el partido4 del marcador
	 * @param partido4 setPartido4
	 */
	public void setPartido4(String partido4) {
		this.partido4 = partido4;
	}
	/**
     * Metodo que regresa el partido5 del marcador
     * @return Regresa la partido5 del marcador
     */
	public String getPartido5() {
		return partido5;
	}
	
	/**
	 * Metodo que le asigna el partido5 del marcador
	 * @param partido5 setPartido5
	 */
	public void setPartido5(String partido5) {
		this.partido5 = partido5;
	}
	/**
     * Metodo que regresa el partido6 del marcador
     * @return Regresa la partido6 del marcador
     */
	public String getPartido6() {
		return partido6;
	}
	
	/**
	 * Metodo que le asigna el partido6 del marcador
	 * @param partido6 setPartido6
	 */
	public void setPartido6(String partido6) {
		this.partido6 = partido6;
	}
	/**
     * Metodo que regresa el partido7 del marcador
     * @return Regresa la partido7 del marcador
     */
	public String getPartido7() {
		return partido7;
	}
	
	/**
	 * Metodo que le asigna el partido7 del marcador
	 * @param partido7 setPartido7
	 */
	public void setPartido7(String partido7) {
		this.partido7 = partido7;
	}
	/**
     * Metodo que regresa el partido8 del marcador
     * @return Regresa la partido8 del marcador
     */
	public String getPartido8() {
		return partido8;
	}
	
	/**
	 * Metodo que le asigna el partido8 del marcador
	 * @param partido8 setPartido8
	 */
	public void setPartido8(String partido8) {
		this.partido8 = partido8;
	}
	/**
     * Metodo que regresa el partido9 del marcador
     * @return Regresa la partido9 del marcador
     */
	public String getPartido9() {
		return partido9;
	}
	
	/**
	 * Metodo que le asigna el partido9 del marcador
	 * @param partido9 setPartido9
	 */
	public void setPartido9(String partido9) {
		this.partido9 = partido9;
	}
	/**
     * Metodo que regresa el partido10 del marcador
     * @return Regresa la partido10 del marcador
     */
	public String getPartido10() {
		return partido10;
	}
	
	/**
	 * Metodo que le asigna el partido10 del marcador
	 * @param partido10 setPartido10
	 */
	public void setPartido10(String partido10) {
		this.partido10 = partido10;
	}
	/**
     * Metodo que regresa el partido11 del marcador
     * @return Regresa la partido11 del marcador
     */
	public String getPartido11() {
		return partido11;
	}
	
	
	/**
	 * Metodo que le asigna el partido11 del marcador
	 * @param partido11 setPartido11
	 */
	
	public void setPartido11(String partido11) {
		this.partido11 = partido11;
	}
	/**
     * Metodo que regresa el partido12 del marcador
     * @return Regresa la partido12 del marcador
     */
	public String getPartido12() {
		return partido12; 
	}
	
	/**
	 * Metodo que le asigna el partido12 del marcador
	 * @param partido12 setPartido12
	 */
	public void setPartido12(String partido12) {
		this.partido12 = partido12;
	}
	/**
     * Metodo que regresa el partido13 del marcador
     * @return Regresa la partido13 del marcador
     */
	public String getPartido13() {
		return partido13;
	}
	
	/**
	 * Metodo que le asigna el partido13 del marcador
	 * @param partido13 setPartido13
	 */
	public void setPartido13(String partido13) {
		this.partido13 = partido13;
	}
	/**
     * Metodo que regresa el partido14 del marcador
     * @return Regresa la partido14 del marcador
     */
	public String getPartido14() {
		return partido14;
	}
	/**
     * Metodo que le asigna el partido14 del marcador
     * @param partido14 setPartido14
     */
	public void setPartido14(String partido14) {
		this.partido14 = partido14;
	}
	/**
     * Metodo que regresa la lista de ganadores
     * @return Regresa la lista de ganadores
     */
	public List<String> getListaGanadores() {
		return listaGanadores;
	}
	
	/**
	 * Metodo que le asigna la lista de ganadores
	 * @param listaGanadores setListaGanadores
	 */
	public void setListaGanadores(List<String> listaGanadores) {
		this.listaGanadores = listaGanadores;
	}
	
}
