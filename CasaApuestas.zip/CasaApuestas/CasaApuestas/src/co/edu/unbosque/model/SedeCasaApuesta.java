package co.edu.unbosque.model;

import java.io.Serializable;
/**
 * Clase SedeCasaApuesta
 *
 */
public class SedeCasaApuesta extends CasaApuesta implements Serializable{
	/**
	 * ubicaci�n de sede
	 */
	private String ubicacion;
	/**
	 * ubicaci�n de numeroEmpleados
	 */
	private int numeroEmpleados;
	
	public SedeCasaApuesta() {
		super();
	}
	/**
	 * Constructor con 2 parametros
	 * 
	 * @param ubicacion    ubicacion de sede
	 * @param numeroEmpleados    numeroEmpleados de sedes
	 */
	public SedeCasaApuesta(String ubicacion, int numeroEmpleados) {
		super();
		this.ubicacion = ubicacion;
		this.numeroEmpleados = numeroEmpleados;
	}
	/**
     * Metodo que regresa la ubicaci�n de la sede
     * @return Regresa la ubicaci�n de la sede
     */
	public String getUbicacion() {
		return ubicacion;
	}
	
	/**
	 * Metodo que le asigna la ubicaci�n de la sede
	 * @param ubicacion setUbicacion
	 */
	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}
	/**
     * Metodo que regresa el NumeroEmpleados
     * @return Regresa el NumeroEmpleados de la sede
     */
	public int getNumeroEmpleados() {
		return numeroEmpleados;
	}
	
	/**
	 * Metodo que le asigna el NumeroEmpleados de la sede
	 * @param numeroEmpleados setNumeroEmpleados
	 */
	public void setNumeroEmpleados(int numeroEmpleados) {
		this.numeroEmpleados = numeroEmpleados;
	}

}
