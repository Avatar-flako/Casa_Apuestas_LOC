package co.edu.unbosque.model;

import java.io.Serializable;
/**
 * Clase Casa Apuesta
 * 
 */
public class Juego extends CasaApuesta {
	 /**
     * Se crea una constante deportivo  de la clase 
     */
	public static final String DEPORTIVO = "deportivo";
	 /**
     * Se crea una constante loteria  de la clase 
     */
	public static final String LOTERIA = "loter�a";
	 /**
     * Se crea una constante chance  de la clase 
     */
	public static final String CHANCE = "chance";
	
	/**
	 * Nombre del juego
	 */
	private String nombreJuego;
	/**
	 * Tipo del juego
	 */
	private String tipoJuego;
	/**
	 * Presupuesto del juego
	 */
	private double presupuestoJuego;
	
	public Juego() {
		super();
	}
	/**
	 * Constructor con 3 parametros
	 * 
	 * @param nombreJuego    nombre del juego
	 * @param tipoJuego    tipo del juego
	 * @param presupuestoJuego    presupuesto del juego
	 */
	public Juego(String nombreJuego, String tipoJuego, double presupuestoJuego) {
		this.nombreJuego = nombreJuego;
		this.tipoJuego = tipoJuego;
		this.presupuestoJuego = presupuestoJuego;
	}
	/**
     * Metodo que regresa el nombre del juego
     * @return Regresa el nombre del juego
     */
	public String getNombreJuego() {
		return nombreJuego;
	}
	 /**
     * Metodo que le asigna nombre al juego
     * @param nombreJuego setNombreJuego
     */
	public void setNombreJuego(String nombreJuego) {
		this.nombreJuego = nombreJuego;
	}
	/**
     * Metodo que regresa el tipo del juego
     * @return Regresa el tipo del juego
     */
	public String getTipoJuego() {
		return tipoJuego;
	}
	 /**
     * Metodo que le asigna tipo al juego
     * @param tipoJuego setTipoJuego
     */
	public void setTipoJuego(String tipoJuego) {
		this.tipoJuego = tipoJuego;
	}
	/**
     * Metodo que regresa el presupuesto del juego
     * @return Regresa el presupuesto del juego
     */
	public double getPresupuestoJuego() {
		return presupuestoJuego;
	}
	 /**
     * Metodo que le asigna presupuesto del juego
     * @param presupuestoJuego setPresupuestoJuego
     */
	public void setPresupuestoJuego(double presupuestoJuego) {
		this.presupuestoJuego = presupuestoJuego;
	}
	
	
	
	

}
