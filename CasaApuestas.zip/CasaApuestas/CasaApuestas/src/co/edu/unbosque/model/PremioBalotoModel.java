package co.edu.unbosque.model;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;
/**
 * Clase Premio Baloto 
 * 
 */
public class PremioBalotoModel implements Serializable {
	/**
	 * fecha del baloto
	 */
	private Date fecha;
	/**
	 * numero del baloto
	 */
	private Long numero;
	/**
	 * signo del baloto
	 */
	private String signo;
	/**
	 * Lista de ganadores
	 */
	private List<String> listaGanadores;
	
	public PremioBalotoModel() {
	}
	/**
     * Metodo que regresa la fecha del baloto
     * @return Regresa la fecha del baloto
     */
	public Date getFecha() {
		return fecha;
	}
	 /**
     * Metodo que le asigna la fecha del baloto
     * @param fecha setFecha
     */
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	/**
     * Metodo que regresa el numero del baloto
     * @return Regresa el numero del baloto
     */
	public Long getNumero() {
		return numero;
	}
	/**
     * Metodo que le asigna el numero del baloto
     * @param numero setNumer
     */
	public void setNumero(Long numero) {
		this.numero = numero;
	}

	/**
     * Metodo que regresa el signo del baloto
     * @return Regresa el signo  del baloto
     */
	public String getSigno() {
		return signo;
	}
	/**
     * Metodo que le asigna el signo del baloto
     * @param signo setSigno
     */
	public void setSigno(String signo) {
		this.signo = signo;
	}
	/**
     * Metodo que regresa la lista de ganadores
     * @return Regresa la lista de ganadores
     */
	public List<String> getListaGanadores() {
		return listaGanadores;
	}
	/**
     * Metodo que le asigna la lista de ganadores
     * @param listaGanadores setListaGanadores
     */
	public void setListaGanadores(List<String> listaGanadores) {
		this.listaGanadores = listaGanadores;
	}
	
}
