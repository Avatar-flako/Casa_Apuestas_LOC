package co.edu.unbosque.controller;

/**
 * Se instancia el objeto HomeController e Inicializa la aplicacion
 *
 */
public class Main {

	public static void main(String[] args) {
		HomeController home = new HomeController();
	}

}
