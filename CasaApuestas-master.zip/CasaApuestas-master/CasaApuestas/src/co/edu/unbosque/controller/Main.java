package co.edu.unbosque.controller;

public class Main {

	public static void main(String[] args) {
		HomeController home = new HomeController();
	}

}
