package co.edu.unbosque.view;

public class AbrirCerrarVentanas {

	public AbrirCerrarVentanas() {
		// TODO Auto-generated constructor stub
	}

}
