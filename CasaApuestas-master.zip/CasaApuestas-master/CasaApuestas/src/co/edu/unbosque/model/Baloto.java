package co.edu.unbosque.model;

public class Baloto extends Apuesta {

	private Long numero;

	public Long getNumero() {
		return numero;
	}

	public void setNumero(Long numero) {
		this.numero = numero;
	}

	
}
